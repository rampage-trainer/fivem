FMCP (FiveM Compatibility Patcher) is a small tool that helps you patch existing Rampage builds to work 
with newer FiveM versions that are not yet supported by the mainline releases.

EXPLANATION

To load an .asi mod into FiveM for compatibility reasons, 
the mod needs to have a special "flag" in its resources file called FX_ASI_BUILD XXXX, 
where XXXX corresponds to the specific game build.

This tool allows you to modify these entries, making the mod compatible without creating a new binary.


HOW TO USE

1. Download a fresh build of the latest Rampage Trainer for FiveM.
2. Open FMCP.exe.

From here, you have two options:

Option 1:
Drag Rampage.asi into the "Drop File Here" field. 
The patcher will then attempt to detect your last run FiveM build 
and patch the earliest supported build number (2189) to your last run build.

Option 2:
Enter the source game build number you want to replace, along with your target build number.

Example: 3570 to 3751